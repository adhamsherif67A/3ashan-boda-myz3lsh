Ocean search and survey targets. Units: meters; Z up.
STL files contain geometry only. Colors/materials are in the simulation model.sdf.
Models are simplified identification references, not scans or exact copies of photographed artifacts.
Bell: about 0.40m high. Anchor: about 0.90m long. Propeller: about 0.80m diameter.
See the separate pilot_photo_briefing.zip for actual photographs and licensing credits.
